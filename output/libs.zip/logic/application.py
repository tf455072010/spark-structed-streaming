from ctutil import spark_base

spark = spark_base.SparkBase()

sc, ss = spark.get_spark_context()