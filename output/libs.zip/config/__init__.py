APPLICATION_NAME = 'stag.datalink_v2.streaming'
APPLICATION_VERS = "1.0.0"
